package com.nahuannghia.shopnhn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShopNHNApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShopNHNApplication.class, args);
	}

}
