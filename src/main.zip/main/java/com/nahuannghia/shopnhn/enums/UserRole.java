package com.nahuannghia.shopnhn.enums;

public enum UserRole {
    CUSTOMER, ADMIN
}
