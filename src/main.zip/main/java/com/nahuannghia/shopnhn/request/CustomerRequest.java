package com.nahuannghia.shopnhn.request;

public class CustomerRequest {
}
