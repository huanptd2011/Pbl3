package com.nahuannghia.shopnhn.request;

import lombok.Data;

@Data
public class PaymentMethodRequest {
    private String paymentMethodName;
    
}
